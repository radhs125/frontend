package com.training;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.training.business.bean.PurchaseBean;
import com.training.dao.ReportsDataAccess;
import com.training.service.ReportsServiceImpl;

@ExtendWith(MockitoExtension.class)
public class ReportsServiceTest {

	@Mock
	private ReportsDataAccess reportsDataAccess;

	@InjectMocks
	private ReportsServiceImpl reportsService;

	@Test
	public void testGetVendorWisePurchaseDetails() {
		Date fromDate = new Date(System.currentTimeMillis() - 30L * 24 * 60 * 60 * 1000);
		Date toDate = new Date();

		PurchaseBean bean = new PurchaseBean();
		bean.setVendorName("Only Vimal");
		bean.setTransactionId("P_ONL_08202026_C00");

		when(reportsDataAccess.getVendorWisePurchaseDetails(any(Date.class), any(Date.class), anyString()))
				.thenReturn(Collections.singletonList(bean));

		List<PurchaseBean> result = reportsService.getVendorWisePurchaseDetails(fromDate, toDate, "Only Vimal");

		assertNotNull(result);
		assertEquals(1, result.size());
		assertEquals("Only Vimal", result.get(0).getVendorName());
	}

	@Test
	public void testGetVendorWisePurchaseDetailsEmpty() {
		Date fromDate = new Date(System.currentTimeMillis() - 30L * 24 * 60 * 60 * 1000);
		Date toDate = new Date();

		when(reportsDataAccess.getVendorWisePurchaseDetails(any(Date.class), any(Date.class), anyString()))
				.thenReturn(Collections.emptyList());

		List<PurchaseBean> result = reportsService.getVendorWisePurchaseDetails(fromDate, toDate, "Unknown Vendor");

		assertNotNull(result);
		assertEquals(0, result.size());
	}
}