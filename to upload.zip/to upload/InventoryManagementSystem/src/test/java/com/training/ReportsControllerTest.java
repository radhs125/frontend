package com.training;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import com.training.business.bean.PurchaseBean;
import com.training.business.bean.VendorWisePurchaseReportBean;
import com.training.service.ReportsService;
import com.training.web.controller.ReportsController;

@ExtendWith(MockitoExtension.class)
public class ReportsControllerTest {

	@Mock
	private ReportsService reportsService;

	@InjectMocks
	private ReportsController reportsController;

	@Test
	public void testGetPurchaseDetails() throws Exception {
		Date fromDate = new Date(System.currentTimeMillis() - 30L * 24 * 60 * 60 * 1000);
		Date toDate = new Date();

		VendorWisePurchaseReportBean requestBean = new VendorWisePurchaseReportBean(fromDate, toDate, "Only Vimal");

		PurchaseBean purchaseBean = new PurchaseBean();
		purchaseBean.setVendorName("Only Vimal");
		purchaseBean.setTransactionId("P_ONL_08202026_C00");

		when(reportsService.getVendorWisePurchaseDetails(fromDate, toDate, "Only Vimal"))
				.thenReturn(Collections.singletonList(purchaseBean));

		ResponseEntity<List<PurchaseBean>> response = reportsController.getPurchaseDetails(requestBean);

		assertNotNull(response.getBody());
		assertEquals(1, response.getBody().size());
		assertEquals("Only Vimal", response.getBody().get(0).getVendorName());
	}

	@Test
	public void testGetPurchaseDetailsEmpty() throws Exception {
		Date fromDate = new Date(System.currentTimeMillis() - 30L * 24 * 60 * 60 * 1000);
		Date toDate = new Date();

		VendorWisePurchaseReportBean requestBean = new VendorWisePurchaseReportBean(fromDate, toDate, "Unknown Vendor");

		when(reportsService.getVendorWisePurchaseDetails(fromDate, toDate, "Unknown Vendor"))
				.thenReturn(Collections.emptyList());

		ResponseEntity<List<PurchaseBean>> response = reportsController.getPurchaseDetails(requestBean);

		assertNotNull(response.getBody());
		assertEquals(0, response.getBody().size());
	}
}