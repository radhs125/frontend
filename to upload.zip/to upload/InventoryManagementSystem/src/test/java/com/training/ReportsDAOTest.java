package com.training;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.training.business.bean.PurchaseBean;
import com.training.dao.ReportsDAO;
import com.training.dao.ReportsDataAccess;
import com.training.entity.PurchaseEntity;

@ExtendWith(MockitoExtension.class)
public class ReportsDAOTest {

	@Mock
	private ReportsDAO reportsDAO;

	@InjectMocks
	private ReportsDataAccess reportsDataAccess;

	@Test
	public void testGetVendorWisePurchaseDetails() {
		Date fromDate = new Date(System.currentTimeMillis() - 30L * 24 * 60 * 60 * 1000);
		Date toDate = new Date();

		PurchaseEntity entity = new PurchaseEntity();
		entity.setPurchaseId(101);
		entity.setTransactionId("P_ONL_08202026_C00");
		entity.setVendorName("Only Vimal");
		entity.setMaterialCategoryId("C001");
		entity.setMaterialTypeId("T001");
		entity.setBrandName("BrandX");
		entity.setUnitId("U001");
		entity.setQuantity(5);
		entity.setPurchaseAmount(500.0);
		entity.setPurchaseDate(new Date());
		entity.setStatus("SUCCESS");

		when(reportsDAO.getVendorWisePurchaseDetails(any(Date.class), any(Date.class), anyString()))
				.thenReturn(Collections.singletonList(entity));

		List<PurchaseBean> result = reportsDataAccess.getVendorWisePurchaseDetails(fromDate, toDate, "Only Vimal");

		assertNotNull(result);
		assertEquals(1, result.size());
		assertEquals(101, result.get(0).getPurchaseId());
		assertEquals("Only Vimal", result.get(0).getVendorName());
		assertEquals("SUCCESS", result.get(0).getStatus());
	}
}