package com.training;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.http.ResponseEntity;

import com.training.web.controller.HomeController;

public class HomeControllerTest {

	private HomeController homeController = new HomeController();

	@Test
	public void testShowHomePage() {
		ResponseEntity<HomeController.WelcomeResponse> response = homeController.showHomePage();

		assertNotNull(response.getBody());
		assertEquals("Welcome to the Home Page!", response.getBody().getMessage());
	}
}