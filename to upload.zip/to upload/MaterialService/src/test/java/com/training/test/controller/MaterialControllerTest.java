package com.training.test.controller;

import static org.mockito.Mockito.when;
import static org.hamcrest.Matchers.hasSize;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.training.business.bean.MaterialCategoryBean;
import com.training.controller.MaterialController;
import com.training.service.MaterialService;

@WebMvcTest(MaterialController.class)
public class MaterialControllerTest {

    private static final Logger logger = LoggerFactory.getLogger(MaterialControllerTest.class);

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private MaterialService materialServiceMock;

    @Test
    public void healthMaterialControllerTest() throws Exception {

        mockMvc.perform(MockMvcRequestBuilders.get("/health"))
                .andExpect(status().isOk())
                .andExpect(content().string("Material Service is UP"));
    }

    @Test
    public void getMaterialCategoriesTest() throws Exception {

        List<MaterialCategoryBean> materialCategoryBeans = new ArrayList<>();

        materialCategoryBeans.add(new MaterialCategoryBean("C001", "Thread"));
        materialCategoryBeans.add(new MaterialCategoryBean("C002", "Cloth"));
        materialCategoryBeans.add(new MaterialCategoryBean("C003", "Button"));

        when(materialServiceMock.getMaterialCategories()).thenReturn(materialCategoryBeans);

        mockMvc.perform(MockMvcRequestBuilders.get("/material/controller/getMaterialCategories"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$", hasSize(3)))
                .andExpect(jsonPath("$[0].categoryId").exists())
                .andExpect(jsonPath("$[0].categoryName").exists())
                .andExpect(jsonPath("$[0].categoryId").isString())
                .andExpect(jsonPath("$[0].categoryName").isString())
                .andExpect(jsonPath("$[0].categoryId").value("C001"))
                .andExpect(jsonPath("$[0].categoryName").value("Thread"));
    }

    @Test
    public void getMaterialCategoryByIdTest() throws Exception {

        String categoryId = "C001";
        MaterialCategoryBean bean = new MaterialCategoryBean("C001", "Thread");

        when(materialServiceMock.getMaterialCategoryById(categoryId)).thenReturn(bean);

        mockMvc.perform(MockMvcRequestBuilders.get("/material/controller/getMaterialCategoryById/" + categoryId))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.categoryId").exists())
                .andExpect(jsonPath("$.categoryName").exists())
                .andExpect(jsonPath("$.categoryId").isString())
                .andExpect(jsonPath("$.categoryName").isString())
                .andExpect(jsonPath("$.categoryId").value("C001"))
                .andExpect(jsonPath("$.categoryName").value("Thread"));
    }

}