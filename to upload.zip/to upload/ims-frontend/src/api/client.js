import axios from "axios";

const BASE_URL = process.env.REACT_APP_API_BASE_URL || "http://localhost:8086";

const http = axios.create({
  baseURL: BASE_URL,
  headers: { "Content-Type": "application/json" }
});

export async function fetchWelcomeMessage() {
  const { data } = await http.get("/welcome");
  return data.message;
}

export async function fetchVendors() {
  const { data } = await http.get("/vendors");
  return data;
}

export async function fetchCategories() {
  const { data } = await http.get("/categories");
  return data;
}

export async function fetchUnitAndTypeList(materialCategoryId) {
  const { data } = await http.post("/getUnitAndTypeList", { materialCategoryId });
  return data;
}

export async function submitPurchase(purchasePayload) {
  const { data } = await http.post("/addPurchaseDetail", purchasePayload);
  return data;
}

export async function fetchVendorWisePurchaseReport({ fromDate, toDate, vendorName }) {
  const { data } = await http.post("/report/controller/getPurchaseDetails", {
    fromDate,
    toDate,
    vendorName
  });
  return data;
}

// Normalizes backend/axios errors into a single readable message for the UI.
export function extractErrorMessage(error) {
  if (error?.response?.data) {
    const body = error.response.data;
    if (typeof body === "string") return body;
    if (body.message) return body.message;
    if (Array.isArray(body.errors) && body.errors.length) {
      return body.errors.map((e) => e.defaultMessage || e.message).join(" ");
    }
  }
  return error?.message || "Something went wrong. Please try again.";
}
