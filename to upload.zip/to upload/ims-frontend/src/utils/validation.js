// Central validation rules for the Purchase Entry and Reports forms.
// Each validator returns an error string, or "" when the value is valid.

export function required(value, label) {
  if (value === null || value === undefined) return `${label} is required.`;
  if (typeof value === "string" && value.trim() === "") return `${label} is required.`;
  return "";
}

export function positiveInteger(value, label) {
  if (value === "" || value === null || value === undefined) return `${label} is required.`;
  const num = Number(value);
  if (!Number.isInteger(num)) return `${label} must be a whole number.`;
  if (num <= 0) return `${label} must be greater than zero.`;
  return "";
}

export function positiveAmount(value, label) {
  if (value === "" || value === null || value === undefined) return `${label} is required.`;
  const num = Number(value);
  if (Number.isNaN(num)) return `${label} must be a number.`;
  if (num <= 0) return `${label} must be greater than zero.`;
  // Guard against more than 2 decimal places, since this is a currency amount.
  if (!/^\d+(\.\d{1,2})?$/.test(String(value))) {
    return `${label} can have at most 2 decimal places.`;
  }
  return "";
}

export function pastDate(value, label) {
  if (!value) return `${label} is required.`;
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return `${label} must be a valid date (yyyy-mm-dd).`;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  if (date.getTime() >= today.getTime()) return `${label} must be a date in the past.`;
  return "";
}

export function requiredDate(value, label) {
  if (!value) return `${label} is required.`;
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return `${label} must be a valid date (yyyy-mm-dd).`;
  return "";
}

export function dateRange(fromValue, toValue) {
  if (!fromValue || !toValue) return "";
  const from = new Date(fromValue);
  const to = new Date(toValue);
  if (from.getTime() > to.getTime()) {
    return "The from date must be on or before the to date.";
  }
  return "";
}

export function brandName(value) {
  const base = required(value, "Brand name");
  if (base) return base;
  if (value.trim().length < 2) return "Brand name must be at least 2 characters.";
  if (!/^[A-Za-z0-9 &.'-]+$/.test(value.trim())) {
    return "Brand name can only contain letters, numbers, spaces, and & . ' -";
  }
  return "";
}

// Returns true only when every value in the errors map is an empty string.
export function isFormValid(errors) {
  return Object.values(errors).every((message) => !message);
}
