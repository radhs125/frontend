import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { fetchWelcomeMessage, extractErrorMessage } from "../api/client";

export default function Home() {
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    let active = true;
    fetchWelcomeMessage()
      .then((msg) => {
        if (active) setMessage(msg);
      })
      .catch((err) => {
        if (active) setError(extractErrorMessage(err));
      });
    return () => {
      active = false;
    };
  }, []);

  return (
    <div className="page page--wide">
      <div className="hero">
        <h1>Inventory Management System</h1>
        <p>
          Record purchase orders against your vendors and materials, then pull
          vendor purchase history whenever you need it.
        </p>
        <span className={`status-pill ${error ? "status-pill--error" : "status-pill--ok"}`}>
          {error ? "Service unreachable" : message || "Connecting…"}
        </span>
      </div>

      <div className="tile-grid">
        <Link to="/purchase-entry" className="tile tile--blue">
          <h2>Record a purchase</h2>
          <p>Log a new material purchase against a vendor, category, and unit.</p>
        </Link>
        <Link to="/reports" className="tile tile--green">
          <h2>Purchase reports</h2>
          <p>Pull a vendor's purchase history across a date range.</p>
        </Link>
      </div>
    </div>
  );
}