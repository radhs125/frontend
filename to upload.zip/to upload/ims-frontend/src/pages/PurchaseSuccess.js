import { Link, Navigate, useLocation } from "react-router-dom";

export default function PurchaseSuccess() {
  const location = useLocation();
  const state = location.state;

  if (!state?.purchase) {
    return <Navigate to="/purchase-entry" replace />;
  }

  const { purchase, categoryName, typeName, unitName } = state;

  return (
    <div className="page">
      <div className="page-header">
        <h1>Purchase recorded</h1>
        <p>Purchase details added successfully.</p>
      </div>

      <div className="receipt">
        <div className="receipt__txn">
          <div style={{ fontSize: "12px", color: "#5b6472", marginBottom: "4px" }}>Transaction ID</div>
          {purchase.transactionId}
        </div>

        <div className="receipt__row">
          <span>Vendor name</span>
          <span>{purchase.vendorName}</span>
        </div>
        <div className="receipt__row">
          <span>Material category</span>
          <span>{categoryName || purchase.materialCategoryId}</span>
        </div>
        <div className="receipt__row">
          <span>Material Type</span>
          <span>{typeName || purchase.materialTypeId}</span>
        </div>
        <div className="receipt__row">
          <span>Unit</span>
          <span>{unitName || purchase.unitId}</span>
        </div>
        <div className="receipt__row">
          <span>Brand name</span>
          <span>{purchase.brandName}</span>
        </div>
        <div className="receipt__row">
          <span>Quantity</span>
          <span>{purchase.quantity}</span>
        </div>
        <div className="receipt__row">
          <span>Purchase Amount(₹)</span>
          <span>₹{purchase.purchaseAmount}</span>
        </div>
        <div className="receipt__row">
          <span>Purchase Date</span>
          <span>{formatDate(purchase.purchaseDate)}</span>
        </div>
        <div className="receipt__row">
          <span>Status</span>
          <span>{purchase.status}</span>
        </div>

        <div className="receipt__actions">
          <Link to="/purchase-entry" className="btn">
            Record another purchase
          </Link>
          <Link to="/reports" className="btn btn--secondary">
            View reports
          </Link>
        </div>
      </div>
    </div>
  );
}

function formatDate(value) {
  if (!value) return "—";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return String(value);
  return date.toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" });
}