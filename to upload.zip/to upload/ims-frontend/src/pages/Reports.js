import { useEffect, useMemo, useState } from "react";
import {
  fetchVendors,
  fetchCategories,
  fetchUnitAndTypeList,
  fetchVendorWisePurchaseReport,
  extractErrorMessage
} from "../api/client";
import { required, requiredDate, dateRange } from "../utils/validation";

const initialForm = { vendorName: "", fromDate: "", toDate: "" };

export default function Reports() {
  const [vendors, setVendors] = useState([]);
  const [form, setForm] = useState(initialForm);
  const [touched, setTouched] = useState({});
  const [results, setResults] = useState(null);
  const [searching, setSearching] = useState(false);
  const [serverError, setServerError] = useState("");

  const [categoryMap, setCategoryMap] = useState({});
  const [typeUnitMap, setTypeUnitMap] = useState({});

  useEffect(() => {
    fetchVendors().then(setVendors).catch((err) => setServerError(extractErrorMessage(err)));
  }, []);

  useEffect(() => {
    fetchCategories().then((cats) => {
      setCategoryMap(Object.fromEntries(cats.map((c) => [c.categoryId, c.categoryName])));
    });
  }, []);

  useEffect(() => {
    if (!results || results.length === 0) return;
    const uniqueCategoryIds = [...new Set(results.map((r) => r.materialCategoryId))];
    Promise.all(uniqueCategoryIds.map((id) => fetchUnitAndTypeList(id))).then((lists) => {
      const map = {};
      lists.forEach((data) => {
        (data.materialTypeList || []).forEach((t) => (map[t.typeId] = t.typeName));
        (data.unitList || []).forEach((u) => (map[u.unitId] = u.unitName));
      });
      setTypeUnitMap(map);
    });
  }, [results]);

  const errors = useMemo(() => {
    const rangeMessage = dateRange(form.fromDate, form.toDate);
    return {
      vendorName: required(form.vendorName, "Vendor"),
      fromDate: requiredDate(form.fromDate, "From date"),
      toDate: requiredDate(form.toDate, "To date") || rangeMessage
    };
  }, [form]);

  const isValid = !errors.vendorName && !errors.fromDate && !errors.toDate;
  const selectedVendor = vendors.find((v) => v.vendorName === form.vendorName);

  function updateField(name, value) {
    setForm((prev) => ({ ...prev, [name]: value }));
  }

  function markTouched(name) {
    setTouched((prev) => ({ ...prev, [name]: true }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setTouched({ vendorName: true, fromDate: true, toDate: true });
    setServerError("");
    if (!isValid) return;

    setSearching(true);
    setResults(null);
    try {
      const data = await fetchVendorWisePurchaseReport(form);
      setResults(data || []);
    } catch (err) {
      setServerError(extractErrorMessage(err));
    } finally {
      setSearching(false);
    }
  }

  return (
    <div className="page">
      <div className="page-header">
        <h1>Purchase reports</h1>
        <p>Pick a vendor and a date range to pull their purchase history.</p>
      </div>

      {serverError && <div className="banner">{serverError}</div>}

      <form className="form-panel" onSubmit={handleSubmit} noValidate>
        <div className="form-grid">
          <div className="field">
            <label htmlFor="vendorName">Vendor</label>
            <select
              id="vendorName"
              value={form.vendorName}
              className={touched.vendorName ? (errors.vendorName ? "is-invalid" : "is-valid") : ""}
              onChange={(e) => updateField("vendorName", e.target.value)}
              onBlur={() => markTouched("vendorName")}
            >
              <option value="">Select a vendor</option>
              {vendors.map((v) => (
                <option key={v.vendorId} value={v.vendorName}>
                  {v.vendorName}
                </option>
              ))}
            </select>
            <span className="field-error">{touched.vendorName ? errors.vendorName : ""}</span>
          </div>

          <div className="field">
            <label htmlFor="fromDate">From date</label>
            <input
              id="fromDate"
              type="date"
              value={form.fromDate}
              className={touched.fromDate ? (errors.fromDate ? "is-invalid" : "is-valid") : ""}
              onChange={(e) => updateField("fromDate", e.target.value)}
              onBlur={() => markTouched("fromDate")}
            />
            <span className="field-error">{touched.fromDate ? errors.fromDate : ""}</span>
          </div>

          <div className="field">
            <label htmlFor="toDate">To date</label>
            <input
              id="toDate"
              type="date"
              value={form.toDate}
              className={touched.toDate ? (errors.toDate ? "is-invalid" : "is-valid") : ""}
              onChange={(e) => updateField("toDate", e.target.value)}
              onBlur={() => markTouched("toDate")}
            />
            <span className="field-error">{touched.toDate ? errors.toDate : ""}</span>
          </div>
        </div>

        <div className="form-actions">
          <button type="submit" className="btn" disabled={searching}>
            {searching ? "Searching…" : "Generate report"}
          </button>
        </div>
      </form>

      {selectedVendor && results !== null && !searching && (
        <div className="vendor-info">
          <span><strong>Vendor Address:</strong>{selectedVendor.vendorAddress}</span>
          <span><strong>Contact Person:</strong>{selectedVendor.contactPerson}</span>
          <span><strong>Contact Number:</strong>{selectedVendor.contactNumber}</span>
        </div>
      )}

      {searching && <div className="loading-state">Fetching purchase records…</div>}

      {results !== null && !searching && (
        results.length === 0 ? (
          <div className="empty-state">No purchases found for {form.vendorName} in this date range.</div>
        ) : (
          <table>
            <thead>
              <tr>
                <th>S.No</th>
                <th>Material Category</th>
                <th>Material Type</th>
                <th>Brand</th>
                <th>Quantity</th>
                <th>Unit</th>
                <th>Price (₹)</th>
                <th>Purchase Date</th>
              </tr>
            </thead>
            <tbody>
              {results.map((row, index) => (
                <tr key={row.transactionId || row.purchaseId}>
                  <td>{index + 1}</td>
                  <td>{categoryMap[row.materialCategoryId] || row.materialCategoryId}</td>
                  <td>{typeUnitMap[row.materialTypeId] || row.materialTypeId}</td>
                  <td>{row.brandName}</td>
                  <td>{row.quantity}</td>
                  <td>{typeUnitMap[row.unitId] || row.unitId}</td>
                  <td>₹{row.purchaseAmount}</td>
                  <td>{formatDate(row.purchaseDate)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )
      )}
    </div>
  );
}

function formatDate(value) {
  if (!value) return "—";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return String(value);
  return date.toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" });
}