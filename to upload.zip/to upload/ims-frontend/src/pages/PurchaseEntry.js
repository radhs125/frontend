import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import FormField from "../components/FormField";
import {
  fetchVendors,
  fetchCategories,
  fetchUnitAndTypeList,
  submitPurchase,
  extractErrorMessage
} from "../api/client";
import {
  required,
  positiveInteger,
  positiveAmount,
  pastDate,
  brandName
} from "../utils/validation";

const initialForm = {
  vendorName: "",
  materialCategoryId: "",
  materialTypeId: "",
  brandName: "",
  unitId: "",
  quantity: "",
  purchaseAmount: "",
  purchaseDate: ""
};

export default function PurchaseEntry() {
  const navigate = useNavigate();

  const [vendors, setVendors] = useState([]);
  const [categories, setCategories] = useState([]);
  const [types, setTypes] = useState([]);
  const [units, setUnits] = useState([]);

  const [form, setForm] = useState(initialForm);
  const [touched, setTouched] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [serverError, setServerError] = useState("");

  useEffect(() => {
    fetchVendors().then(setVendors).catch((err) => setServerError(extractErrorMessage(err)));
    fetchCategories().then(setCategories).catch((err) => setServerError(extractErrorMessage(err)));
  }, []);

  useEffect(() => {
    if (!form.materialCategoryId) {
      setTypes([]);
      setUnits([]);
      return;
    }
    fetchUnitAndTypeList(form.materialCategoryId)
      .then((data) => {
        setTypes(data.materialTypeList || []);
        setUnits(data.unitList || []);
      })
      .catch((err) => setServerError(extractErrorMessage(err)));
  }, [form.materialCategoryId]);

  const errors = useMemo(
    () => ({
      vendorName: required(form.vendorName, "Vendor"),
      materialCategoryId: required(form.materialCategoryId, "Material category"),
      materialTypeId: required(form.materialTypeId, "Material type"),
      brandName: brandName(form.brandName),
      unitId: required(form.unitId, "Unit"),
      quantity: positiveInteger(form.quantity, "Quantity"),
      purchaseAmount: positiveAmount(form.purchaseAmount, "Purchase amount"),
      purchaseDate: pastDate(form.purchaseDate, "Purchase date")
    }),
    [form]
  );

  const isValid = Object.values(errors).every((m) => !m);

  function updateField(name, value) {
    setForm((prev) => {
      const next = { ...prev, [name]: value };
      if (name === "materialCategoryId") {
        next.materialTypeId = "";
        next.unitId = "";
      }
      return next;
    });
  }

  function markTouched(name) {
    setTouched((prev) => ({ ...prev, [name]: true }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setTouched({
      vendorName: true,
      materialCategoryId: true,
      materialTypeId: true,
      brandName: true,
      unitId: true,
      quantity: true,
      purchaseAmount: true,
      purchaseDate: true
    });
    setServerError("");
    if (!isValid) return;

    setSubmitting(true);
    try {
      const payload = {
        vendorName: form.vendorName,
        materialCategoryId: form.materialCategoryId,
        materialTypeId: form.materialTypeId,
        brandName: form.brandName.trim(),
        unitId: form.unitId,
        quantity: Number(form.quantity),
        purchaseAmount: Number(form.purchaseAmount),
        purchaseDate: form.purchaseDate
      };
      const response = await submitPurchase(payload);
      const category = categories.find((c) => c.categoryId === form.materialCategoryId);
      const type = types.find((t) => t.typeId === form.materialTypeId);
      const unit = units.find((u) => u.unitId === form.unitId);
      navigate("/purchase-success", {
        state: {
          purchase: response.purchase,
          categoryName: category?.categoryName,
          typeName: type?.typeName,
          unitName: unit?.unitName
        }
});
    } catch (err) {
      setServerError(extractErrorMessage(err));
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="page">
      <div className="page-header">
        <h1>Record a purchase</h1>
        <p>Fill in every field below.</p>
      </div>

      {serverError && <div className="banner">{serverError}</div>}

      <form className="form-panel" onSubmit={handleSubmit} noValidate>
        <div className="form-grid">
          <FormField id="vendorName" label="Vendor" error={errors.vendorName} touched={touched.vendorName}>
            <select
              id="vendorName"
              value={form.vendorName}
              onChange={(e) => updateField("vendorName", e.target.value)}
              onBlur={() => markTouched("vendorName")}
            >
              <option value="">Select a vendor</option>
              {vendors.map((v) => (
                <option key={v.vendorId} value={v.vendorName}>
                  {v.vendorName}
                </option>
              ))}
            </select>
          </FormField>

          <FormField
            id="materialCategoryId"
            label="Material category"
            error={errors.materialCategoryId}
            touched={touched.materialCategoryId}
          >
            <select
              id="materialCategoryId"
              value={form.materialCategoryId}
              onChange={(e) => updateField("materialCategoryId", e.target.value)}
              onBlur={() => markTouched("materialCategoryId")}
            >
              <option value="">Select a category</option>
              {categories.map((c) => (
                <option key={c.categoryId} value={c.categoryId}>
                  {c.categoryName}
                </option>
              ))}
            </select>
          </FormField>

          <FormField
            id="materialTypeId"
            label="Material type"
            error={errors.materialTypeId}
            touched={touched.materialTypeId}
          >
            <select
              id="materialTypeId"
              value={form.materialTypeId}
              disabled={!form.materialCategoryId}
              onChange={(e) => updateField("materialTypeId", e.target.value)}
              onBlur={() => markTouched("materialTypeId")}
            >
              <option value="">Select a type</option>
              {types.map((t) => (
                <option key={t.typeId} value={t.typeId}>
                  {t.typeName}
                </option>
              ))}
            </select>
          </FormField>

          <FormField id="unitId" label="Unit" error={errors.unitId} touched={touched.unitId}>
            <select
              id="unitId"
              value={form.unitId}
              disabled={!form.materialCategoryId}
              onChange={(e) => updateField("unitId", e.target.value)}
              onBlur={() => markTouched("unitId")}
            >
              <option value="">Select a unit</option>
              {units.map((u) => (
                <option key={u.unitId} value={u.unitId}>
                  {u.unitName}
                </option>
              ))}
            </select>
          </FormField>

          <FormField id="brandName" label="Brand name" error={errors.brandName} touched={touched.brandName}>
            <input
              id="brandName"
              type="text"
              value={form.brandName}
              onChange={(e) => updateField("brandName", e.target.value)}
              onBlur={() => markTouched("brandName")}
            />
          </FormField>

          <FormField id="quantity" label="Quantity" error={errors.quantity} touched={touched.quantity}>
            <input
              id="quantity"
              type="number"
              value={form.quantity}
              onChange={(e) => updateField("quantity", e.target.value)}
              onBlur={() => markTouched("quantity")}
            />
          </FormField>

          <FormField
            id="purchaseAmount"
            label="Purchase amount"
            error={errors.purchaseAmount}
            touched={touched.purchaseAmount}
          >
            <input
              id="purchaseAmount"
              type="number"
              step="0.01"
              value={form.purchaseAmount}
              onChange={(e) => updateField("purchaseAmount", e.target.value)}
              onBlur={() => markTouched("purchaseAmount")}
            />
          </FormField>

          <FormField
            id="purchaseDate"
            label="Purchase date"
            error={errors.purchaseDate}
            touched={touched.purchaseDate}
          >
            <input
              id="purchaseDate"
              type="date"
              value={form.purchaseDate}
              onChange={(e) => updateField("purchaseDate", e.target.value)}
              onBlur={() => markTouched("purchaseDate")}
            />
          </FormField>
        </div>

        <div className="form-actions">
          <button type="submit" className="btn" disabled={submitting}>
            {submitting ? "Saving…" : "Save purchase"}
          </button>
        </div>
      </form>
    </div>
  );
}