import { Route, Routes } from "react-router-dom";
import NavBar from "./components/NavBar";
import Home from "./pages/Home";
import PurchaseEntry from "./pages/PurchaseEntry";
import PurchaseSuccess from "./pages/PurchaseSuccess";
import Reports from "./pages/Reports";

export default function App() {
  return (
    <div className="app-shell">
      <NavBar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/purchase-entry" element={<PurchaseEntry />} />
        <Route path="/purchase-success" element={<PurchaseSuccess />} />
        <Route path="/reports" element={<Reports />} />
      </Routes>
    </div>
  );
}
