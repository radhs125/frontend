import { cloneElement } from "react";

export default function FormField({ id, label, error, touched, children }) {
  const showInvalid = touched && !!error;
  const showValid = touched && !error;
  const existingClass = children.props.className || "";
  const stateClass = showInvalid ? "is-invalid" : showValid ? "is-valid" : "";

  return (
    <div className="field">
      <label htmlFor={id}>{label}</label>
      {cloneElement(children, { className: `${existingClass} ${stateClass}`.trim() })}
      <span className="field-error">{showInvalid ? error : ""}</span>
    </div>
  );
}