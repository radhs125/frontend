import { NavLink } from "react-router-dom";

export default function NavBar() {
  const linkClass = ({ isActive }) =>
    isActive ? "nav__link nav__link--active" : "nav__link";

  return (
    <nav className="nav">
      <NavLink to="/" className="nav__brand">
        Inventory Ledger
      </NavLink>
      <div className="nav__links">
        <NavLink to="/" end className={linkClass}>
          Home
        </NavLink>
        <NavLink to="/purchase-entry" className={linkClass}>
          New purchase
        </NavLink>
        <NavLink to="/reports" className={linkClass}>
          Reports
        </NavLink>
      </div>
    </nav>
  );
}