# IMS Frontend (Create React App)

React frontend for the Inventory Management System, built with Create React App.

- **Home** — landing page, links to Purchase Entry and Reports
- **Purchase Entry** — cascading vendor/category/type/unit dropdowns, full client-side validation
- **Purchase Success** — confirmation screen with the generated transaction ID
- **Reports** — vendor + date range filter, ledger-style results table with an empty state

## Prerequisites

- Node.js 18+
- `InventoryManagementSystem` running locally (default `http://localhost:8086`), which itself needs `VendorService` and `MaterialService` running.

## Setup

Drop the contents of this project into your existing `my-app` folder (created via
`npx create-react-app my-app`), replacing `src/App.js`, `src/index.js`, and
`public/index.html`, and adding the rest of the `src/` subfolders as-is.

```bash
npm install axios react-router-dom
npm start
```

The app runs at `http://localhost:3000` (matches the `@CrossOrigin(origins = "http://localhost:3000")`
already configured on the IMS controllers).

## Configuration

Edit `.env` to point at a different backend host/port. Create React App requires
the `REACT_APP_` prefix for any environment variable to be exposed to the browser:

```
REACT_APP_API_BASE_URL=http://localhost:8086
```

Restart `npm start` after changing `.env` — CRA only reads it at startup.

## API endpoints used

| Page | Method | Endpoint |
|---|---|---|
| Home | GET | `/welcome` |
| Purchase Entry | GET | `/vendors`, `/categories` |
| Purchase Entry | POST | `/getUnitAndTypeList` |
| Purchase Entry | POST | `/addPurchaseDetail` |
| Reports | GET | `/vendors` |
| Reports | POST | `/report/controller/getPurchaseDetails` |

## Validation rules (Purchase Entry)

- All fields required
- Quantity: whole number, greater than zero
- Purchase amount: numeric, greater than zero, up to 2 decimal places
- Purchase date: must be a valid date in the past
- Brand name: 2+ characters, letters/numbers/spaces/`& . ' -` only

## Validation rules (Reports)

- Vendor required
- From date and To date required
- From date must be on or before To date
