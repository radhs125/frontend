import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import FormField from "../components/FormField";
import { IconCart, IconBox } from "../components/Icon";
import {
  fetchVendors,
  fetchCategories,
  fetchUnitAndTypeList,
  submitPurchase,
  extractErrorMessage
} from "../api/client.js";
import {
  required,
  positiveInteger,
  positiveAmount,
  pastDate,
  brandName
} from "../utils/validation.js";

const initialForm = {
  vendorName: "",
  materialCategoryId: "",
  materialTypeId: "",
  brandName: "",
  unitId: "",
  quantity: "",
  purchaseAmount: "",
  purchaseDate: ""
};

export default function PurchaseEntry() {
  const navigate = useNavigate();

  const [vendors, setVendors] = useState([]);
  const [categories, setCategories] = useState([]);
  const [types, setTypes] = useState([]);
  const [units, setUnits] = useState([]);

  const [form, setForm] = useState(initialForm);
  const [touched, setTouched] = useState({});
  const [loadingLookups, setLoadingLookups] = useState(true);
  const [loadingUnitType, setLoadingUnitType] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [serverError, setServerError] = useState("");

  useEffect(() => {
    let active = true;
    Promise.all([fetchVendors(), fetchCategories()])
      .then(([vendorList, categoryList]) => {
        if (!active) return;
        setVendors(vendorList || []);
        setCategories(categoryList || []);
      })
      .catch((err) => {
        if (active) setServerError(extractErrorMessage(err));
      })
      .finally(() => {
        if (active) setLoadingLookups(false);
      });
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    if (!form.materialCategoryId) {
      setTypes([]);
      setUnits([]);
      return;
    }
    let active = true;
    setLoadingUnitType(true);
    fetchUnitAndTypeList(form.materialCategoryId)
      .then((data) => {
        if (!active) return;
        setTypes(data.materialTypeList || []);
        setUnits(data.unitList || []);
      })
      .catch((err) => {
        if (active) setServerError(extractErrorMessage(err));
      })
      .finally(() => {
        if (active) setLoadingUnitType(false);
      });
    return () => {
      active = false;
    };
  }, [form.materialCategoryId]);

  const errors = useMemo(() => {
    return {
      vendorName: required(form.vendorName, "Vendor"),
      materialCategoryId: required(form.materialCategoryId, "Material category"),
      materialTypeId: required(form.materialTypeId, "Material type"),
      brandName: brandName(form.brandName),
      unitId: required(form.unitId, "Unit"),
      quantity: positiveInteger(form.quantity, "Quantity"),
      purchaseAmount: positiveAmount(form.purchaseAmount, "Purchase amount"),
      purchaseDate: pastDate(form.purchaseDate, "Purchase date")
    };
  }, [form]);

  const isValid = Object.values(errors).every((message) => !message);

  // Derived purely from current form state + already-fetched lookups —
  // no fabricated data, just a live readout of what's about to be submitted.
  const selectedCategory = categories.find((c) => c.categoryId === form.materialCategoryId);
  const selectedType = types.find((t) => t.typeId === form.materialTypeId);
  const selectedUnit = units.find((u) => u.unitId === form.unitId);
  const amountEntered = form.purchaseAmount && !errors.purchaseAmount ? Number(form.purchaseAmount) : null;

  function updateField(name, value) {
    setForm((prev) => {
      const next = { ...prev, [name]: value };
      // Changing category invalidates any previously chosen type/unit.
      if (name === "materialCategoryId") {
        next.materialTypeId = "";
        next.unitId = "";
      }
      return next;
    });
  }

  function markTouched(name) {
    setTouched((prev) => ({ ...prev, [name]: true }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setTouched({
      vendorName: true,
      materialCategoryId: true,
      materialTypeId: true,
      brandName: true,
      unitId: true,
      quantity: true,
      purchaseAmount: true,
      purchaseDate: true
    });
    setServerError("");

    if (!isValid) return;

    setSubmitting(true);
    try {
      const category = categories.find((c) => c.categoryId === form.materialCategoryId);
      const type = types.find((t) => t.typeId === form.materialTypeId);
      const unit = units.find((u) => u.unitId === form.unitId);

      const payload = {
        vendorName: form.vendorName,
        materialCategoryId: form.materialCategoryId,
        materialTypeId: form.materialTypeId,
        brandName: form.brandName.trim(),
        unitId: form.unitId,
        quantity: Number(form.quantity),
        purchaseAmount: Number(form.purchaseAmount),
        purchaseDate: form.purchaseDate
      };

      const response = await submitPurchase(payload);

      navigate("/purchase-success", {
        state: {
          purchase: response.purchase,
          categoryName: category?.categoryName,
          typeName: type?.typeName,
          unitName: unit?.unitName
        }
      });
    } catch (err) {
      setServerError(extractErrorMessage(err));
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="page">
      <div className="page-header">
        <span className="page-header__icon">
          <IconCart />
        </span>
        <div>
          <p className="page-header__eyebrow">IMS // 02</p>
          <h1>Record a purchase</h1>
          <p>Fill in every field below. Fields marked with an error can't be submitted until corrected.</p>
        </div>
      </div>

      {serverError && <div className="banner">{serverError}</div>}

      <div className="entry-layout">
      <form className="form-panel" onSubmit={handleSubmit} noValidate>
        <p className="form-panel__section-title">
          <IconBox /> Purchase details
        </p>
        <div className="form-grid">
          <FormField id="vendorName" label="Vendor" error={errors.vendorName} touched={touched.vendorName}>
            <select
              id="vendorName"
              value={form.vendorName}
              disabled={loadingLookups}
              onChange={(e) => updateField("vendorName", e.target.value)}
              onBlur={() => markTouched("vendorName")}
            >
              <option value="">
                {loadingLookups ? "Loading vendors…" : "Select a vendor"}
              </option>
              {vendors.map((v) => (
                <option key={v.vendorId} value={v.vendorName}>
                  {v.vendorName}
                </option>
              ))}
            </select>
          </FormField>

          <FormField
            id="materialCategoryId"
            label="Material category"
            error={errors.materialCategoryId}
            touched={touched.materialCategoryId}
          >
            <select
              id="materialCategoryId"
              value={form.materialCategoryId}
              disabled={loadingLookups}
              onChange={(e) => updateField("materialCategoryId", e.target.value)}
              onBlur={() => markTouched("materialCategoryId")}
            >
              <option value="">
                {loadingLookups ? "Loading categories…" : "Select a category"}
              </option>
              {categories.map((c) => (
                <option key={c.categoryId} value={c.categoryId}>
                  {c.categoryName}
                </option>
              ))}
            </select>
          </FormField>

          <FormField
            id="materialTypeId"
            label="Material type"
            error={errors.materialTypeId}
            touched={touched.materialTypeId}
          >
            <select
              id="materialTypeId"
              value={form.materialTypeId}
              disabled={!form.materialCategoryId || loadingUnitType}
              onChange={(e) => updateField("materialTypeId", e.target.value)}
              onBlur={() => markTouched("materialTypeId")}
            >
              <option value="">
                {!form.materialCategoryId
                  ? "Select a category first"
                  : loadingUnitType
                  ? "Loading types…"
                  : "Select a type"}
              </option>
              {types.map((t) => (
                <option key={t.typeId} value={t.typeId}>
                  {t.typeName}
                </option>
              ))}
            </select>
          </FormField>

          <FormField id="unitId" label="Unit" error={errors.unitId} touched={touched.unitId}>
            <select
              id="unitId"
              value={form.unitId}
              disabled={!form.materialCategoryId || loadingUnitType}
              onChange={(e) => updateField("unitId", e.target.value)}
              onBlur={() => markTouched("unitId")}
            >
              <option value="">
                {!form.materialCategoryId
                  ? "Select a category first"
                  : loadingUnitType
                  ? "Loading units…"
                  : "Select a unit"}
              </option>
              {units.map((u) => (
                <option key={u.unitId} value={u.unitId}>
                  {u.unitName}
                </option>
              ))}
            </select>
          </FormField>

          <FormField id="brandName" label="Brand name" error={errors.brandName} touched={touched.brandName}>
            <input
              id="brandName"
              type="text"
              placeholder="e.g. BrandX"
              value={form.brandName}
              onChange={(e) => updateField("brandName", e.target.value)}
              onBlur={() => markTouched("brandName")}
            />
          </FormField>

          <FormField id="quantity" label="Quantity" error={errors.quantity} touched={touched.quantity}>
            <input
              id="quantity"
              type="number"
              min="1"
              step="1"
              placeholder="e.g. 5"
              value={form.quantity}
              onChange={(e) => updateField("quantity", e.target.value)}
              onBlur={() => markTouched("quantity")}
            />
          </FormField>

          <FormField
            id="purchaseAmount"
            label="Purchase amount"
            error={errors.purchaseAmount}
            touched={touched.purchaseAmount}
          >
            <input
              id="purchaseAmount"
              type="number"
              min="0.01"
              step="0.01"
              placeholder="e.g. 500.00"
              value={form.purchaseAmount}
              onChange={(e) => updateField("purchaseAmount", e.target.value)}
              onBlur={() => markTouched("purchaseAmount")}
            />
          </FormField>

          <FormField
            id="purchaseDate"
            label="Purchase date"
            error={errors.purchaseDate}
            touched={touched.purchaseDate}
          >
            <input
              id="purchaseDate"
              type="date"
              value={form.purchaseDate}
              max={new Date(Date.now() - 86400000).toISOString().slice(0, 10)}
              onChange={(e) => updateField("purchaseDate", e.target.value)}
              onBlur={() => markTouched("purchaseDate")}
            />
          </FormField>
        </div>

        <div className="form-actions">
          <button type="submit" className="btn" disabled={submitting}>
            {submitting ? "Saving…" : "Save purchase"}
          </button>
          <span className={`form-note ${isValid ? "form-note--ok" : ""}`}>
            {isValid ? "✓ All fields look good." : "Some fields still need attention."}
          </span>
        </div>
      </form>

      <aside className="preview-panel">
        <p className="preview-panel__title">
          <IconBox /> LIVE PREVIEW
        </p>
        <dl>
          <div className="preview-row">
            <dt>Vendor</dt>
            <dd className={form.vendorName ? "" : "is-empty"}>{form.vendorName || "Not selected"}</dd>
          </div>
          <div className="preview-row">
            <dt>Category</dt>
            <dd className={selectedCategory ? "" : "is-empty"}>
              {selectedCategory?.categoryName || "Not selected"}
            </dd>
          </div>
          <div className="preview-row">
            <dt>Type</dt>
            <dd className={selectedType ? "" : "is-empty"}>{selectedType?.typeName || "Not selected"}</dd>
          </div>
          <div className="preview-row">
            <dt>Unit</dt>
            <dd className={selectedUnit ? "" : "is-empty"}>{selectedUnit?.unitName || "Not selected"}</dd>
          </div>
          <div className="preview-row">
            <dt>Brand</dt>
            <dd className={form.brandName ? "" : "is-empty"}>{form.brandName || "Not entered"}</dd>
          </div>
          <div className="preview-row">
            <dt>Quantity</dt>
            <dd className={form.quantity ? "" : "is-empty"}>{form.quantity || "Not entered"}</dd>
          </div>
        </dl>
        <div className="preview-total">
          <dt>Amount</dt>
          <dd>{amountEntered !== null ? formatCurrency(amountEntered) : "—"}</dd>
        </div>
      </aside>
      </div>
    </div>
  );
}

function formatCurrency(amount) {
  return new Intl.NumberFormat(undefined, { style: "currency", currency: "USD" }).format(amount);
}
