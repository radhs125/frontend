import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { fetchWelcomeMessage, extractErrorMessage } from "../api/client";
import { IconCart, IconChart, IconArrow } from "../components/Icon";

export default function Home() {
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    fetchWelcomeMessage()
      .then((msg) => {
        if (active) setMessage(msg);
      })
      .catch((err) => {
        if (active) setError(extractErrorMessage(err));
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, []);

  return (
    <div className="page">
      <div className="hero">
        <p className="hero__eyebrow">INVENTORY MANAGEMENT SYSTEM</p>
        <h1>Track purchases, vendors, and materials in one ledger.</h1>
        <p>
          Record purchase orders against your vendors and materials, then pull vendor
          purchase history whenever you need it.
        </p>
        <span className="hero__status">
          <span className={`hero__status-dot ${error ? "hero__status-dot--error" : ""}`} />
          {loading ? "Connecting to inventory service…" : error ? "Service unreachable" : message}
        </span>
      </div>

      <div className="tile-grid">
        <Link to="/purchase-entry" className="tile">
          <span className="tile__icon">
            <IconCart />
          </span>
          <span className="tile__body">
            <h2>
              Record a purchase <IconArrow />
            </h2>
            <p>Log a new material purchase against a vendor, category, and unit.</p>
          </span>
        </Link>
        <Link to="/reports" className="tile">
          <span className="tile__icon">
            <IconChart />
          </span>
          <span className="tile__body">
            <h2>
              Purchase reports <IconArrow />
            </h2>
            <p>Pull a vendor's purchase history across a date range.</p>
          </span>
        </Link>
      </div>
    </div>
  );
}
