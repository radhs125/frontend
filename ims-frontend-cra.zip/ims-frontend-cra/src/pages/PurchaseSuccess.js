import { Link, Navigate, useLocation } from "react-router-dom";
import { IconCheck, IconPrinter } from "../components/Icon";

export default function PurchaseSuccess() {
  const location = useLocation();
  const state = location.state;

  // Guards against someone landing here directly without a completed submission.
  if (!state?.purchase) {
    return <Navigate to="/purchase-entry" replace />;
  }

  const { purchase, categoryName, typeName, unitName } = state;

  return (
    <div className="page">
      <div className="page-header">
        <span className="page-header__icon">
          <IconCheck />
        </span>
        <div>
          <p className="page-header__eyebrow">IMS // 03</p>
          <h1>Purchase recorded</h1>
          <p>Keep the transaction ID below for your records.</p>
        </div>
      </div>

      <div className="receipt">
        <div className="receipt__header">
          <div className="receipt__stamp">
            <IconCheck />
          </div>
          <div>
            <h1>Purchase details added successfully</h1>
            <p>Vendor: {purchase.vendorName}</p>
          </div>
        </div>

        <div className="receipt__txn">
          <div>
            <span className="receipt__txn-label">Transaction ID</span>
            {purchase.transactionId}
          </div>
          <span className="status-pill">{purchase.status}</span>
        </div>

        <dl className="receipt__rows">
          <div className="receipt__row">
            <dt>Purchase ID</dt>
            <dd>{purchase.purchaseId}</dd>
          </div>
          <div className="receipt__row">
            <dt>Vendor</dt>
            <dd>{purchase.vendorName}</dd>
          </div>
          <div className="receipt__row">
            <dt>Material category</dt>
            <dd>{categoryName || purchase.materialCategoryId}</dd>
          </div>
          <div className="receipt__row">
            <dt>Material type</dt>
            <dd>{typeName || purchase.materialTypeId}</dd>
          </div>
          <div className="receipt__row">
            <dt>Brand</dt>
            <dd>{purchase.brandName}</dd>
          </div>
          <div className="receipt__row">
            <dt>Unit</dt>
            <dd>{unitName || purchase.unitId}</dd>
          </div>
          <div className="receipt__row">
            <dt>Quantity</dt>
            <dd>{purchase.quantity}</dd>
          </div>
          <div className="receipt__row">
            <dt>Purchase amount</dt>
            <dd>{formatCurrency(purchase.purchaseAmount)}</dd>
          </div>
          <div className="receipt__row">
            <dt>Purchase date</dt>
            <dd>{formatDate(purchase.purchaseDate)}</dd>
          </div>
        </dl>

        <div className="receipt__actions">
          <Link to="/purchase-entry" className="btn">
            Record another purchase
          </Link>
          <Link to="/reports" className="btn btn--secondary">
            View reports
          </Link>
          <button type="button" className="btn btn--secondary" onClick={() => window.print()}>
            <IconPrinter /> Print
          </button>
        </div>
      </div>
    </div>
  );
}

function formatCurrency(amount) {
  if (amount === undefined || amount === null) return "—";
  return new Intl.NumberFormat(undefined, { style: "currency", currency: "USD" }).format(amount);
}

function formatDate(value) {
  if (!value) return "—";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return String(value);
  return date.toLocaleDateString();
}
