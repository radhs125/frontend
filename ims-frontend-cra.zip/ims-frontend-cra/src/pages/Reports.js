import { useEffect, useMemo, useState } from "react";
import FormField from "../components/FormField";
import { IconChart, IconBox } from "../components/Icon";
import { fetchVendors, fetchVendorWisePurchaseReport, extractErrorMessage } from "../api/client.js";
import { required, requiredDate, dateRange } from "../utils/validation.js";

const initialForm = { vendorName: "", fromDate: "", toDate: "" };

export default function Reports() {
  const [vendors, setVendors] = useState([]);
  const [loadingVendors, setLoadingVendors] = useState(true);
  const [form, setForm] = useState(initialForm);
  const [touched, setTouched] = useState({});
  const [results, setResults] = useState(null);
  const [searching, setSearching] = useState(false);
  const [serverError, setServerError] = useState("");

  useEffect(() => {
    let active = true;
    fetchVendors()
      .then((list) => {
        if (active) setVendors(list || []);
      })
      .catch((err) => {
        if (active) setServerError(extractErrorMessage(err));
      })
      .finally(() => {
        if (active) setLoadingVendors(false);
      });
    return () => {
      active = false;
    };
  }, []);

  const errors = useMemo(() => {
    const rangeMessage = dateRange(form.fromDate, form.toDate);
    return {
      vendorName: required(form.vendorName, "Vendor"),
      fromDate: requiredDate(form.fromDate, "From date"),
      toDate: requiredDate(form.toDate, "To date") || rangeMessage,
      dateRangeOnly: rangeMessage
    };
  }, [form]);

  const isValid = !errors.vendorName && !errors.fromDate && !errors.toDate;

  function updateField(name, value) {
    setForm((prev) => ({ ...prev, [name]: value }));
  }

  function markTouched(name) {
    setTouched((prev) => ({ ...prev, [name]: true }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setTouched({ vendorName: true, fromDate: true, toDate: true });
    setServerError("");

    if (!isValid) return;

    setSearching(true);
    setResults(null);
    try {
      const data = await fetchVendorWisePurchaseReport(form);
      setResults(data || []);
    } catch (err) {
      setServerError(extractErrorMessage(err));
    } finally {
      setSearching(false);
    }
  }

  return (
    <div className="page">
      <div className="page-header">
        <span className="page-header__icon">
          <IconChart />
        </span>
        <div>
          <p className="page-header__eyebrow">IMS // 04</p>
          <h1>Purchase reports</h1>
          <p>Pick a vendor and a date range to pull their purchase history.</p>
        </div>
      </div>

      {serverError && <div className="banner">{serverError}</div>}

      <form className="form-panel" onSubmit={handleSubmit} noValidate>
        <p className="form-panel__section-title">
          <IconBox /> Report filters
        </p>
        <div className="form-grid form-grid--single">
          <div className="form-grid">
            <FormField id="vendorName" label="Vendor" error={errors.vendorName} touched={touched.vendorName}>
              <select
                id="vendorName"
                value={form.vendorName}
                disabled={loadingVendors}
                onChange={(e) => updateField("vendorName", e.target.value)}
                onBlur={() => markTouched("vendorName")}
              >
                <option value="">
                  {loadingVendors ? "Loading vendors…" : "Select a vendor"}
                </option>
                {vendors.map((v) => (
                  <option key={v.vendorId} value={v.vendorName}>
                    {v.vendorName}
                  </option>
                ))}
              </select>
            </FormField>

            <div />

            <FormField id="fromDate" label="From date" error={errors.fromDate} touched={touched.fromDate}>
              <input
                id="fromDate"
                type="date"
                value={form.fromDate}
                onChange={(e) => updateField("fromDate", e.target.value)}
                onBlur={() => markTouched("fromDate")}
              />
            </FormField>

            <FormField id="toDate" label="To date" error={errors.toDate} touched={touched.toDate}>
              <input
                id="toDate"
                type="date"
                value={form.toDate}
                onChange={(e) => updateField("toDate", e.target.value)}
                onBlur={() => markTouched("toDate")}
              />
            </FormField>
          </div>
        </div>

        <div className="form-actions">
          <button type="submit" className="btn" disabled={searching}>
            {searching ? "Searching…" : "Generate report"}
          </button>
        </div>
      </form>

      {searching && (
        <div className="loading-state">
          <span className="spinner" /> Fetching purchase records…
        </div>
      )}

      {results !== null && !searching && (
        <ReportResults results={results} vendorName={form.vendorName} />
      )}
    </div>
  );
}

function ReportResults({ results, vendorName }) {
  if (results.length === 0) {
    return (
      <div className="ledger-table-wrap">
        <div className="empty-state">
          <span className="empty-state__icon">
            <IconBox />
          </span>
          <strong>No purchases found</strong>
          No records for {vendorName} in the selected date range. Try widening the dates.
        </div>
      </div>
    );
  }

  // Computed directly from the returned records — not invented figures.
  const totalQuantity = results.reduce((sum, row) => sum + (Number(row.quantity) || 0), 0);
  const totalAmount = results.reduce((sum, row) => sum + (Number(row.purchaseAmount) || 0), 0);

  return (
    <>
      <div className="stat-row">
        <div className="stat-card">
          <p className="stat-card__label">Purchases found</p>
          <p className="stat-card__value">{results.length}</p>
        </div>
        <div className="stat-card">
          <p className="stat-card__label">Total quantity</p>
          <p className="stat-card__value">{totalQuantity}</p>
        </div>
        <div className="stat-card stat-card--amber">
          <p className="stat-card__label">Total amount</p>
          <p className="stat-card__value">{formatCurrency(totalAmount)}</p>
        </div>
      </div>

      <div className="ledger-table-wrap">
        <table className="ledger-table">
          <thead>
            <tr>
              <th>Transaction ID</th>
              <th>Purchase date</th>
              <th>Brand</th>
              <th>Quantity</th>
              <th>Amount</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {results.map((row) => (
              <tr key={row.transactionId || row.purchaseId}>
                <td className="mono">{row.transactionId}</td>
                <td>{formatDate(row.purchaseDate)}</td>
                <td>{row.brandName}</td>
                <td>{row.quantity}</td>
                <td className="mono">{formatCurrency(row.purchaseAmount)}</td>
                <td>
                  <span className="status-pill">{row.status}</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}

function formatCurrency(amount) {
  if (amount === undefined || amount === null) return "—";
  return new Intl.NumberFormat(undefined, { style: "currency", currency: "USD" }).format(amount);
}

function formatDate(value) {
  if (!value) return "—";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return String(value);
  return date.toLocaleDateString();
}
