import { cloneElement } from "react";

export default function FormField({
  id,
  label,
  error,
  touched,
  wide,
  optional,
  children
}) {
  const showInvalid = touched && !!error;
  const showValid = touched && !error;

  return (
    <div className={`field ${wide ? "field--wide" : ""}`}>
      <label htmlFor={id}>
        {label} {optional && <span className="optional-hint">(optional)</span>}
      </label>
      {renderWithState(children, showInvalid, showValid)}
      <span className="field-error" role="alert">
        {showInvalid ? error : ""}
      </span>
    </div>
  );
}

// Injects is-valid / is-invalid classes onto the single input/select child
// so FormField stays a thin visual wrapper rather than owning field state.
function renderWithState(child, invalid, valid) {
  const existingClass = child.props.className || "";
  const stateClass = invalid ? "is-invalid" : valid ? "is-valid" : "";
  return cloneElement(child, {
    className: `${existingClass} ${stateClass}`.trim()
  });
}
