import { NavLink } from "react-router-dom";
import { IconLedger, IconCart, IconChart } from "./Icon";

export default function NavBar() {
  const linkClass = ({ isActive }) =>
    isActive ? "nav__link nav__link--active" : "nav__link";

  return (
    <nav className="nav">
      <NavLink to="/" className="nav__brand">
        <span className="nav__brand-icon">
          <IconLedger />
        </span>
        Inventory Ledger
      </NavLink>
      <div className="nav__links">
        <NavLink to="/" end className={linkClass}>
          <IconLedger /> <span>Home</span>
        </NavLink>
        <NavLink to="/purchase-entry" className={linkClass}>
          <IconCart /> <span>New purchase</span>
        </NavLink>
        <NavLink to="/reports" className={linkClass}>
          <IconChart /> <span>Reports</span>
        </NavLink>
      </div>
    </nav>
  );
}
